-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-12-2025 a las 02:39:40
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_clinica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agenda`
--

CREATE TABLE `agenda` (
  `ID_AGENDA` int(11) NOT NULL,
  `ID_MEDICO` int(11) NOT NULL,
  `FECHA_AGENDA` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `agenda`
--

INSERT INTO `agenda` (`ID_AGENDA`, `ID_MEDICO`, `FECHA_AGENDA`) VALUES
(132, 15, '2026-01-07'),
(133, 18, '2026-01-11'),
(134, 4, '2026-01-12'),
(135, 9, '2025-12-20'),
(136, 16, '2025-12-18'),
(137, 10, '2025-12-14'),
(138, 12, '2026-01-05'),
(139, 2, '2025-12-17'),
(140, 9, '2026-01-03'),
(141, 5, '2025-12-18'),
(142, 20, '2025-12-28'),
(143, 11, '2025-12-15'),
(144, 16, '2026-01-02'),
(145, 20, '2026-01-11'),
(146, 18, '2025-12-25'),
(147, 8, '2026-01-06'),
(148, 14, '2025-12-19'),
(149, 16, '2025-12-22'),
(150, 3, '2026-01-04'),
(151, 4, '2026-01-09'),
(152, 17, '2025-12-29'),
(153, 3, '2025-12-18'),
(154, 5, '2026-01-05'),
(155, 1, '2026-01-09'),
(156, 8, '2025-12-17'),
(157, 10, '2025-12-16'),
(158, 19, '2025-12-26'),
(159, 5, '2025-12-14'),
(160, 9, '2026-01-10'),
(161, 8, '2025-12-20'),
(162, 19, '2026-01-09'),
(163, 14, '2026-01-08'),
(164, 2, '2026-01-11'),
(165, 9, '2025-12-25'),
(166, 14, '2025-12-16'),
(167, 11, '2025-12-20'),
(168, 13, '2025-12-28'),
(169, 10, '2026-01-08'),
(170, 20, '2025-12-20'),
(171, 4, '2025-12-23'),
(172, 1, '2025-12-16'),
(173, 7, '2025-12-29'),
(174, 10, '2026-01-11'),
(175, 6, '2026-01-01'),
(176, 5, '2025-12-23'),
(177, 17, '2025-12-22'),
(178, 18, '2026-01-01'),
(179, 9, '2025-12-23'),
(180, 5, '2025-12-22'),
(181, 15, '2026-01-07'),
(182, 19, '2025-12-17'),
(183, 18, '2026-01-10'),
(184, 20, '2025-12-21'),
(185, 5, '2025-12-24'),
(186, 3, '2025-12-30'),
(187, 7, '2025-12-17'),
(188, 10, '2025-12-17'),
(189, 3, '2025-12-21'),
(190, 19, '2026-01-08'),
(191, 10, '2026-01-10'),
(192, 2, '2025-12-30'),
(193, 14, '2025-12-31'),
(194, 20, '2025-12-16'),
(195, 11, '2025-12-24'),
(196, 4, '2026-01-05'),
(197, 7, '2025-12-21'),
(198, 6, '2026-01-04'),
(199, 16, '2026-01-05'),
(200, 7, '2025-12-26'),
(201, 2, '2025-12-18'),
(202, 12, '2025-12-27'),
(203, 10, '2026-01-12'),
(204, 10, '2025-12-30'),
(205, 4, '2025-12-25'),
(206, 7, '2025-12-25'),
(207, 2, '2025-12-16'),
(208, 7, '2025-12-21'),
(209, 7, '2026-01-10'),
(210, 12, '2025-12-19'),
(211, 3, '2025-12-18'),
(212, 7, '2025-12-16'),
(213, 10, '2025-12-20'),
(214, 13, '2025-12-30'),
(215, 16, '2025-12-21'),
(216, 18, '2025-12-31'),
(217, 9, '2025-12-22'),
(218, 3, '2026-01-05'),
(219, 10, '2025-12-14'),
(220, 15, '2025-12-31'),
(221, 14, '2025-12-31'),
(222, 19, '2026-01-11'),
(223, 20, '2026-01-11'),
(224, 18, '2025-12-30'),
(225, 3, '2025-12-15'),
(226, 18, '2025-12-17'),
(227, 19, '2025-12-26'),
(228, 4, '2026-01-03'),
(229, 19, '2025-12-28'),
(230, 16, '2025-12-21'),
(231, 2, '2025-12-29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE `cita` (
  `ID_CITA` int(11) NOT NULL,
  `ID_PACIENTE` int(11) NOT NULL,
  `ID_MEDICO` int(11) NOT NULL,
  `FECHA_CITA` date NOT NULL,
  `HORA_CITA` time NOT NULL,
  `ESTADO_CITA` varchar(20) NOT NULL,
  `TIPO_REGISTRO` varchar(20) NOT NULL,
  `FECHA_REGISTRO` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cita`
--

INSERT INTO `cita` (`ID_CITA`, `ID_PACIENTE`, `ID_MEDICO`, `FECHA_CITA`, `HORA_CITA`, `ESTADO_CITA`, `TIPO_REGISTRO`, `FECHA_REGISTRO`) VALUES
(256, 60, 4, '2025-12-14', '12:14:48', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(257, 36, 16, '2025-07-08', '08:26:29', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(258, 84, 7, '2025-10-31', '09:29:29', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(259, 42, 18, '2025-11-25', '15:32:58', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(260, 37, 11, '2025-09-20', '14:33:22', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(261, 68, 11, '2025-08-09', '15:07:42', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(262, 6, 5, '2025-06-21', '09:43:34', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(263, 83, 20, '2025-10-16', '14:15:40', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(264, 47, 13, '2025-08-23', '10:40:54', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(265, 18, 4, '2025-10-26', '15:12:08', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(266, 32, 12, '2025-07-05', '14:26:40', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(267, 97, 6, '2025-09-08', '14:42:59', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(268, 98, 18, '2025-09-20', '13:47:10', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(269, 41, 13, '2025-06-22', '15:37:06', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(270, 23, 2, '2025-08-22', '15:58:34', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(271, 79, 15, '2025-11-03', '15:54:15', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(272, 82, 3, '2025-11-24', '10:01:06', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(273, 28, 20, '2025-06-26', '15:16:07', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(274, 36, 15, '2025-08-24', '15:17:33', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(275, 33, 13, '2025-11-29', '12:42:49', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(276, 30, 10, '2025-10-08', '12:12:05', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(277, 11, 16, '2025-09-07', '11:13:48', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(278, 41, 18, '2025-11-05', '11:25:32', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(279, 35, 5, '2025-11-15', '08:41:46', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(280, 64, 14, '2025-09-25', '09:46:12', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(281, 64, 12, '2025-11-30', '12:57:42', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(282, 55, 9, '2025-08-30', '13:05:09', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(283, 22, 17, '2025-08-30', '11:13:35', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(284, 34, 13, '2025-11-10', '08:19:28', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(285, 16, 16, '2025-10-10', '12:05:42', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(286, 70, 1, '2025-06-23', '14:25:05', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(287, 41, 13, '2025-07-28', '08:40:05', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(288, 64, 13, '2025-11-06', '09:40:05', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(289, 66, 3, '2025-07-30', '11:04:30', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(290, 20, 19, '2025-12-08', '11:16:47', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(291, 47, 20, '2025-09-21', '11:23:52', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(292, 33, 15, '2025-07-29', '12:45:42', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(293, 83, 9, '2025-08-31', '13:34:57', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(294, 63, 10, '2025-10-09', '11:57:29', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(295, 60, 20, '2025-12-11', '09:46:59', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(296, 78, 3, '2025-11-05', '14:14:40', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(297, 59, 8, '2025-12-11', '08:08:45', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(298, 57, 9, '2025-10-05', '13:40:03', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(299, 43, 20, '2025-08-08', '12:41:29', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(300, 54, 3, '2025-11-28', '08:20:40', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(301, 98, 5, '2025-11-24', '15:31:05', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(302, 83, 4, '2025-10-09', '10:50:39', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(303, 27, 12, '2025-06-21', '09:54:05', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(304, 99, 6, '2025-10-03', '09:33:16', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(305, 2, 6, '2025-10-13', '15:15:11', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(306, 15, 11, '2025-10-21', '15:05:08', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(307, 3, 8, '2025-07-31', '13:31:56', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(308, 79, 7, '2025-11-14', '15:32:12', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(309, 24, 14, '2025-08-10', '11:45:18', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(310, 18, 11, '2025-11-23', '08:13:19', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(311, 60, 13, '2025-10-11', '15:13:13', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(312, 13, 3, '2025-10-11', '10:48:02', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(313, 73, 12, '2025-08-17', '12:52:30', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(314, 16, 8, '2025-09-27', '08:15:11', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(315, 32, 2, '2025-10-07', '13:33:47', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(316, 1, 5, '2025-11-24', '15:04:20', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(317, 51, 6, '2025-07-23', '09:50:49', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(318, 94, 12, '2025-11-29', '13:38:10', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(319, 8, 18, '2025-12-05', '13:35:23', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(320, 97, 1, '2025-10-16', '12:08:03', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(321, 23, 19, '2025-06-20', '08:58:56', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(322, 73, 16, '2025-07-24', '12:52:40', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(323, 23, 17, '2025-09-24', '14:17:46', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(324, 81, 11, '2025-11-21', '08:58:04', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(325, 96, 13, '2025-11-10', '08:56:15', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(326, 60, 17, '2025-11-07', '13:08:14', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(327, 24, 4, '2025-10-29', '13:43:26', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(328, 81, 11, '2025-11-10', '11:09:39', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(329, 77, 10, '2025-12-10', '13:53:45', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(330, 24, 16, '2025-12-03', '08:26:14', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(331, 98, 4, '2025-07-19', '13:17:35', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(332, 56, 3, '2025-12-03', '14:57:16', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(333, 45, 14, '2025-11-25', '11:43:55', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(334, 20, 1, '2025-09-03', '14:05:20', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(335, 71, 19, '2025-09-06', '15:45:22', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(336, 49, 9, '2025-08-31', '13:32:42', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(337, 34, 4, '2025-07-04', '15:57:05', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(338, 50, 16, '2025-10-24', '09:14:35', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(339, 94, 6, '2025-09-21', '12:38:02', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(340, 11, 8, '2025-09-07', '12:55:07', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(341, 41, 20, '2025-08-09', '12:44:05', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(342, 49, 5, '2025-08-17', '13:12:59', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(343, 13, 10, '2025-12-13', '12:46:24', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(344, 30, 7, '2025-07-11', '10:21:35', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(345, 71, 3, '2025-09-20', '08:17:35', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(346, 4, 4, '2025-07-16', '13:05:11', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(347, 98, 15, '2025-08-19', '08:49:19', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(348, 81, 11, '2025-11-02', '12:48:01', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(349, 28, 11, '2025-08-06', '08:41:36', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(350, 42, 20, '2025-09-12', '13:52:15', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(351, 55, 12, '2025-10-13', '15:27:06', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(352, 76, 16, '2025-08-12', '08:43:27', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(353, 92, 15, '2025-07-01', '11:21:24', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(354, 98, 14, '2025-09-03', '13:57:54', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(355, 31, 18, '2025-09-11', '15:43:31', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(356, 13, 10, '2025-12-14', '12:46:05', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(357, 42, 18, '2025-11-03', '11:36:40', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(358, 80, 10, '2025-07-06', '09:03:26', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(359, 21, 16, '2025-11-11', '13:12:42', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(360, 65, 12, '2025-07-04', '14:41:51', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(361, 62, 14, '2025-08-27', '15:36:13', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(362, 32, 2, '2025-09-07', '11:28:56', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(363, 36, 12, '2025-07-20', '10:59:16', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(364, 39, 4, '2025-08-16', '14:42:33', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(365, 66, 19, '2025-08-05', '14:34:54', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(366, 12, 1, '2025-08-05', '12:53:39', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(367, 97, 6, '2025-09-17', '12:59:08', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(368, 83, 2, '2025-07-19', '15:40:19', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(369, 52, 11, '2025-12-12', '12:17:29', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(370, 94, 20, '2025-12-12', '09:21:30', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(371, 39, 5, '2025-12-05', '12:19:26', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(372, 74, 10, '2025-11-18', '10:32:13', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(373, 49, 2, '2025-06-23', '12:41:03', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(374, 64, 3, '2025-07-19', '13:28:28', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(375, 71, 8, '2025-07-26', '14:20:24', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(376, 42, 3, '2025-10-11', '11:27:36', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(377, 53, 3, '2025-11-26', '08:53:14', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(378, 77, 3, '2025-10-03', '12:39:34', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(379, 82, 15, '2025-11-24', '11:33:52', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(380, 65, 2, '2025-09-26', '15:43:01', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(381, 63, 5, '2025-10-20', '14:45:44', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(382, 79, 3, '2025-10-25', '08:11:16', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(383, 67, 9, '2025-11-04', '14:15:37', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(384, 58, 7, '2025-07-28', '15:42:36', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(385, 55, 18, '2025-07-12', '12:55:09', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(386, 47, 12, '2025-09-21', '13:02:39', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(387, 88, 19, '2025-06-19', '09:31:40', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(388, 59, 1, '2025-10-24', '11:22:05', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(389, 97, 20, '2025-11-24', '12:30:45', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(390, 17, 13, '2025-08-07', '13:18:39', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(391, 76, 5, '2025-07-10', '13:24:55', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(392, 71, 3, '2025-09-29', '14:30:25', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(393, 15, 5, '2025-08-31', '10:38:16', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(394, 57, 10, '2025-07-24', '11:53:56', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(395, 68, 2, '2025-10-14', '12:02:43', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(396, 35, 17, '2025-12-11', '13:23:03', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(397, 63, 12, '2025-12-08', '11:27:02', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(398, 77, 18, '2025-12-05', '13:08:26', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(399, 73, 10, '2025-11-13', '11:48:04', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(400, 50, 2, '2025-07-18', '15:36:12', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(401, 61, 12, '2025-11-16', '08:06:20', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(402, 63, 11, '2025-08-10', '15:43:55', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(403, 34, 12, '2025-06-27', '15:36:14', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(404, 92, 8, '2025-12-04', '09:45:36', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(405, 1, 4, '2025-07-28', '11:13:24', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(406, 12, 18, '2025-12-05', '13:00:43', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(407, 92, 14, '2025-08-21', '09:23:20', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(408, 23, 10, '2025-08-06', '09:32:53', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(409, 45, 3, '2025-10-05', '12:10:55', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(410, 76, 19, '2025-10-01', '10:04:00', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(411, 30, 20, '2025-12-02', '10:58:18', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(412, 84, 15, '2025-12-08', '08:29:28', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(413, 27, 1, '2025-10-02', '15:18:47', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(414, 86, 7, '2025-12-03', '10:47:04', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(415, 89, 7, '2025-07-08', '12:01:53', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(416, 39, 11, '2025-09-05', '09:19:38', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(417, 89, 13, '2025-09-13', '13:13:04', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(418, 18, 17, '2025-08-06', '08:34:23', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(419, 12, 8, '2025-09-25', '09:13:18', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(420, 16, 14, '2025-12-14', '15:35:21', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(421, 82, 14, '2025-12-13', '15:45:06', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(422, 39, 9, '2025-06-26', '11:57:37', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(423, 26, 9, '2025-10-23', '09:40:29', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(424, 81, 5, '2025-08-20', '12:48:59', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(425, 48, 16, '2025-09-18', '08:39:49', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(426, 70, 20, '2025-08-10', '13:07:07', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(427, 33, 2, '2025-09-25', '15:50:52', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(428, 62, 11, '2025-08-11', '15:34:31', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(429, 7, 3, '2025-09-19', '15:53:10', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(430, 99, 10, '2025-10-06', '12:09:15', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(431, 84, 6, '2025-07-04', '13:34:34', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(432, 25, 3, '2025-07-14', '15:18:51', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(433, 49, 11, '2025-11-29', '15:17:50', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(434, 95, 9, '2025-10-28', '08:29:35', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(435, 39, 16, '2025-08-08', '09:55:19', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(436, 79, 4, '2025-09-28', '13:26:36', 'ATENDIDA', 'ONLINE', '2025-12-14 13:40:57'),
(437, 12, 3, '2025-11-03', '14:28:44', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(438, 70, 9, '2025-06-29', '11:48:02', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(439, 33, 9, '2025-11-21', '11:06:52', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(440, 30, 15, '2025-08-07', '11:24:04', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(441, 94, 20, '2025-12-07', '10:27:40', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(442, 38, 10, '2025-10-09', '10:50:23', 'PROGRAMADA', 'ONLINE', '2025-12-14 13:40:57'),
(443, 39, 3, '2025-10-14', '11:12:24', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(444, 62, 19, '2025-07-28', '08:56:09', 'ATENDIDA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(445, 85, 9, '2025-08-09', '09:34:52', 'PROGRAMADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(446, 8, 4, '2025-08-11', '15:29:39', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57'),
(447, 83, 16, '2025-09-29', '14:10:21', 'CANCELADA', 'PRESENCIAL', '2025-12-14 13:40:57'),
(448, 44, 5, '2025-07-14', '12:42:13', 'CANCELADA', 'ONLINE', '2025-12-14 13:40:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comprobante_cita`
--

CREATE TABLE `comprobante_cita` (
  `ID_COMPROBANTE` int(11) NOT NULL,
  `ID_CITA` int(11) NOT NULL,
  `FECHA_EMISION` datetime NOT NULL,
  `DATOS_PDF` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comprobante_de_pago`
--

CREATE TABLE `comprobante_de_pago` (
  `ID_COMPRP` int(11) NOT NULL,
  `ID_PAGO` int(11) NOT NULL,
  `NUM_CP` varchar(20) NOT NULL,
  `TIPO_CP` varchar(10) NOT NULL,
  `FECHA_E_CP` datetime NOT NULL,
  `MONTO_T_CP` decimal(8,2) NOT NULL,
  `ESTADO_CP` varchar(15) NOT NULL,
  `OBSERVACION_CP` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidad_medica`
--

CREATE TABLE `disponibilidad_medica` (
  `ID_DISPONIBILIDADM` int(11) NOT NULL,
  `ID_MEDICO` int(11) NOT NULL,
  `FECHA_DM` date NOT NULL,
  `HORARIO_INICIO` time NOT NULL,
  `HORARIO_FIN` time NOT NULL,
  `ESTADO_DM` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `disponibilidad_medica`
--

INSERT INTO `disponibilidad_medica` (`ID_DISPONIBILIDADM`, `ID_MEDICO`, `FECHA_DM`, `HORARIO_INICIO`, `HORARIO_FIN`, `ESTADO_DM`) VALUES
(129, 14, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(130, 3, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(131, 4, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(132, 2, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(133, 1, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(134, 20, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(135, 7, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(136, 20, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(137, 9, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(138, 18, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(139, 13, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(140, 2, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(141, 9, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(142, 12, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(143, 3, '2025-12-25', '08:00:00', '16:00:00', 'DISPONIBLE'),
(144, 10, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(145, 15, '2025-12-20', '08:00:00', '16:00:00', 'DISPONIBLE'),
(146, 4, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(147, 19, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(148, 19, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(149, 18, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(150, 3, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(151, 3, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(152, 19, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(153, 19, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(154, 17, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(155, 3, '2025-12-22', '08:00:00', '16:00:00', 'DISPONIBLE'),
(156, 7, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(157, 6, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(158, 1, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(159, 13, '2025-12-20', '08:00:00', '16:00:00', 'DISPONIBLE'),
(160, 9, '2025-12-25', '08:00:00', '16:00:00', 'DISPONIBLE'),
(161, 10, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(162, 8, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(163, 14, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(164, 15, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(165, 18, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(166, 1, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(167, 8, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(168, 7, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(169, 10, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(170, 7, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(171, 18, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(172, 16, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(173, 19, '2025-12-25', '08:00:00', '16:00:00', 'DISPONIBLE'),
(174, 3, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(175, 9, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(176, 17, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(177, 6, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(178, 17, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(179, 16, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(180, 9, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(181, 5, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(182, 2, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(183, 18, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(184, 17, '2025-12-22', '08:00:00', '16:00:00', 'DISPONIBLE'),
(185, 10, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(186, 17, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(187, 2, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(188, 19, '2025-12-22', '08:00:00', '16:00:00', 'DISPONIBLE'),
(189, 3, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(190, 18, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(191, 3, '2025-12-18', '08:00:00', '16:00:00', 'DISPONIBLE'),
(192, 7, '2025-12-25', '08:00:00', '16:00:00', 'DISPONIBLE'),
(193, 14, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(194, 3, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(195, 19, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(196, 17, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(197, 12, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(198, 6, '2025-12-16', '08:00:00', '16:00:00', 'DISPONIBLE'),
(199, 1, '2025-12-22', '08:00:00', '16:00:00', 'DISPONIBLE'),
(200, 15, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(201, 18, '2025-12-18', '08:00:00', '16:00:00', 'DISPONIBLE'),
(202, 17, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(203, 5, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(204, 5, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(205, 13, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(206, 18, '2025-12-18', '08:00:00', '16:00:00', 'DISPONIBLE'),
(207, 1, '2025-12-14', '08:00:00', '16:00:00', 'DISPONIBLE'),
(208, 4, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE'),
(209, 15, '2025-12-28', '08:00:00', '16:00:00', 'DISPONIBLE'),
(210, 16, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(211, 4, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(212, 3, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(213, 18, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(214, 15, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(215, 2, '2025-12-21', '08:00:00', '16:00:00', 'DISPONIBLE'),
(216, 5, '2025-12-23', '08:00:00', '16:00:00', 'DISPONIBLE'),
(217, 9, '2025-12-19', '08:00:00', '16:00:00', 'DISPONIBLE'),
(218, 9, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(219, 4, '2025-12-24', '08:00:00', '16:00:00', 'DISPONIBLE'),
(220, 16, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(221, 4, '2025-12-15', '08:00:00', '16:00:00', 'DISPONIBLE'),
(222, 1, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(223, 6, '2025-12-25', '08:00:00', '16:00:00', 'DISPONIBLE'),
(224, 19, '2025-12-20', '08:00:00', '16:00:00', 'DISPONIBLE'),
(225, 10, '2025-12-27', '08:00:00', '16:00:00', 'DISPONIBLE'),
(226, 5, '2025-12-20', '08:00:00', '16:00:00', 'DISPONIBLE'),
(227, 11, '2025-12-17', '08:00:00', '16:00:00', 'DISPONIBLE'),
(228, 10, '2025-12-26', '08:00:00', '16:00:00', 'DISPONIBLE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historia_clinica`
--

CREATE TABLE `historia_clinica` (
  `ID_HISTORIACLINICA` int(11) NOT NULL,
  `ID_PACIENTE` int(11) NOT NULL,
  `FECHA_APERTURA` date NOT NULL,
  `OBSERVACIONES` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historia_clinica`
--

INSERT INTO `historia_clinica` (`ID_HISTORIACLINICA`, `ID_PACIENTE`, `FECHA_APERTURA`, `OBSERVACIONES`) VALUES
(639, 1, '2025-12-14', 'Historia clínica generada'),
(640, 2, '2025-12-14', 'Historia clínica generada'),
(641, 3, '2025-12-14', 'Historia clínica generada'),
(642, 4, '2025-12-14', 'Historia clínica generada'),
(643, 5, '2025-12-14', 'Historia clínica generada'),
(644, 6, '2025-12-14', 'Historia clínica generada'),
(645, 7, '2025-12-14', 'Historia clínica generada'),
(646, 8, '2025-12-14', 'Historia clínica generada'),
(647, 9, '2025-12-14', 'Historia clínica generada'),
(648, 10, '2025-12-14', 'Historia clínica generada'),
(649, 11, '2025-12-14', 'Historia clínica generada'),
(650, 12, '2025-12-14', 'Historia clínica generada'),
(651, 13, '2025-12-14', 'Historia clínica generada'),
(652, 14, '2025-12-14', 'Historia clínica generada'),
(653, 15, '2025-12-14', 'Historia clínica generada'),
(654, 16, '2025-12-14', 'Historia clínica generada'),
(655, 17, '2025-12-14', 'Historia clínica generada'),
(656, 18, '2025-12-14', 'Historia clínica generada'),
(657, 19, '2025-12-14', 'Historia clínica generada'),
(658, 20, '2025-12-14', 'Historia clínica generada'),
(659, 21, '2025-12-14', 'Historia clínica generada'),
(660, 22, '2025-12-14', 'Historia clínica generada'),
(661, 23, '2025-12-14', 'Historia clínica generada'),
(662, 24, '2025-12-14', 'Historia clínica generada'),
(663, 25, '2025-12-14', 'Historia clínica generada'),
(664, 26, '2025-12-14', 'Historia clínica generada'),
(665, 27, '2025-12-14', 'Historia clínica generada'),
(666, 28, '2025-12-14', 'Historia clínica generada'),
(667, 29, '2025-12-14', 'Historia clínica generada'),
(668, 30, '2025-12-14', 'Historia clínica generada'),
(669, 31, '2025-12-14', 'Historia clínica generada'),
(670, 32, '2025-12-14', 'Historia clínica generada'),
(671, 33, '2025-12-14', 'Historia clínica generada'),
(672, 34, '2025-12-14', 'Historia clínica generada'),
(673, 35, '2025-12-14', 'Historia clínica generada'),
(674, 36, '2025-12-14', 'Historia clínica generada'),
(675, 37, '2025-12-14', 'Historia clínica generada'),
(676, 38, '2025-12-14', 'Historia clínica generada'),
(677, 39, '2025-12-14', 'Historia clínica generada'),
(678, 40, '2025-12-14', 'Historia clínica generada'),
(679, 41, '2025-12-14', 'Historia clínica generada'),
(680, 42, '2025-12-14', 'Historia clínica generada'),
(681, 43, '2025-12-14', 'Historia clínica generada'),
(682, 44, '2025-12-14', 'Historia clínica generada'),
(683, 45, '2025-12-14', 'Historia clínica generada'),
(684, 46, '2025-12-14', 'Historia clínica generada'),
(685, 47, '2025-12-14', 'Historia clínica generada'),
(686, 48, '2025-12-14', 'Historia clínica generada'),
(687, 49, '2025-12-14', 'Historia clínica generada'),
(688, 50, '2025-12-14', 'Historia clínica generada'),
(689, 51, '2025-12-14', 'Historia clínica generada'),
(690, 52, '2025-12-14', 'Historia clínica generada'),
(691, 53, '2025-12-14', 'Historia clínica generada'),
(692, 54, '2025-12-14', 'Historia clínica generada'),
(693, 55, '2025-12-14', 'Historia clínica generada'),
(694, 56, '2025-12-14', 'Historia clínica generada'),
(695, 57, '2025-12-14', 'Historia clínica generada'),
(696, 58, '2025-12-14', 'Historia clínica generada'),
(697, 59, '2025-12-14', 'Historia clínica generada'),
(698, 60, '2025-12-14', 'Historia clínica generada'),
(699, 61, '2025-12-14', 'Historia clínica generada'),
(700, 62, '2025-12-14', 'Historia clínica generada'),
(701, 63, '2025-12-14', 'Historia clínica generada'),
(702, 64, '2025-12-14', 'Historia clínica generada'),
(703, 65, '2025-12-14', 'Historia clínica generada'),
(704, 66, '2025-12-14', 'Historia clínica generada'),
(705, 67, '2025-12-14', 'Historia clínica generada'),
(706, 68, '2025-12-14', 'Historia clínica generada'),
(707, 69, '2025-12-14', 'Historia clínica generada'),
(708, 70, '2025-12-14', 'Historia clínica generada'),
(709, 71, '2025-12-14', 'Historia clínica generada'),
(710, 72, '2025-12-14', 'Historia clínica generada'),
(711, 73, '2025-12-14', 'Historia clínica generada'),
(712, 74, '2025-12-14', 'Historia clínica generada'),
(713, 75, '2025-12-14', 'Historia clínica generada'),
(714, 76, '2025-12-14', 'Historia clínica generada'),
(715, 77, '2025-12-14', 'Historia clínica generada'),
(716, 78, '2025-12-14', 'Historia clínica generada'),
(717, 79, '2025-12-14', 'Historia clínica generada'),
(718, 80, '2025-12-14', 'Historia clínica generada'),
(719, 81, '2025-12-14', 'Historia clínica generada'),
(720, 82, '2025-12-14', 'Historia clínica generada'),
(721, 83, '2025-12-14', 'Historia clínica generada'),
(722, 84, '2025-12-14', 'Historia clínica generada'),
(723, 85, '2025-12-14', 'Historia clínica generada'),
(724, 86, '2025-12-14', 'Historia clínica generada'),
(725, 87, '2025-12-14', 'Historia clínica generada'),
(726, 88, '2025-12-14', 'Historia clínica generada'),
(727, 89, '2025-12-14', 'Historia clínica generada'),
(728, 90, '2025-12-14', 'Historia clínica generada'),
(729, 91, '2025-12-14', 'Historia clínica generada'),
(730, 92, '2025-12-14', 'Historia clínica generada'),
(731, 93, '2025-12-14', 'Historia clínica generada'),
(732, 94, '2025-12-14', 'Historia clínica generada'),
(733, 95, '2025-12-14', 'Historia clínica generada'),
(734, 96, '2025-12-14', 'Historia clínica generada'),
(735, 97, '2025-12-14', 'Historia clínica generada'),
(736, 98, '2025-12-14', 'Historia clínica generada'),
(737, 99, '2025-12-14', 'Historia clínica generada'),
(738, 100, '2025-12-14', 'Historia clínica generada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario_medico`
--

CREATE TABLE `horario_medico` (
  `ID_HM` int(11) NOT NULL,
  `ID_MEDICO` int(11) NOT NULL,
  `DIA_SEMANA` varchar(10) NOT NULL,
  `HORA_INICIO` time NOT NULL,
  `HORA_FIN` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `horario_medico`
--

INSERT INTO `horario_medico` (`ID_HM`, `ID_MEDICO`, `DIA_SEMANA`, `HORA_INICIO`, `HORA_FIN`) VALUES
(64, 1, 'Martes', '08:00:00', '16:00:00'),
(65, 2, 'Miércoles', '08:00:00', '16:00:00'),
(66, 3, 'Jueves', '08:00:00', '16:00:00'),
(67, 4, 'Viernes', '08:00:00', '16:00:00'),
(68, 5, 'Lunes', '08:00:00', '16:00:00'),
(69, 6, 'Martes', '08:00:00', '16:00:00'),
(70, 7, 'Miércoles', '08:00:00', '16:00:00'),
(71, 8, 'Jueves', '08:00:00', '16:00:00'),
(72, 9, 'Viernes', '08:00:00', '16:00:00'),
(73, 10, 'Lunes', '08:00:00', '16:00:00'),
(74, 11, 'Martes', '08:00:00', '16:00:00'),
(75, 12, 'Miércoles', '08:00:00', '16:00:00'),
(76, 13, 'Jueves', '08:00:00', '16:00:00'),
(77, 14, 'Viernes', '08:00:00', '16:00:00'),
(78, 15, 'Lunes', '08:00:00', '16:00:00'),
(79, 16, 'Martes', '08:00:00', '16:00:00'),
(80, 17, 'Miércoles', '08:00:00', '16:00:00'),
(81, 18, 'Jueves', '08:00:00', '16:00:00'),
(82, 19, 'Viernes', '08:00:00', '16:00:00'),
(83, 20, 'Lunes', '08:00:00', '16:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medico`
--

CREATE TABLE `medico` (
  `ID_MEDICO` int(11) NOT NULL,
  `NOM_M` varchar(60) NOT NULL,
  `APE_M` varchar(60) NOT NULL,
  `ESPECIALIDAD_M` varchar(60) NOT NULL,
  `TELEF_M` varchar(15) NOT NULL,
  `CORREO_M` varchar(80) NOT NULL,
  `HORARIO_TRABAJO` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `medico`
--

INSERT INTO `medico` (`ID_MEDICO`, `NOM_M`, `APE_M`, `ESPECIALIDAD_M`, `TELEF_M`, `CORREO_M`, `HORARIO_TRABAJO`) VALUES
(1, 'Luis', 'Huaman', 'Pediatria', '931109929', 'medico1@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(2, 'Jose', 'Perez', 'Medicina General', '990726670', 'medico2@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(3, 'Juan', 'Rojas', 'Traumatologia', '960303566', 'medico3@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(4, 'Miguel', 'Torres', 'Ginecologia', '929337822', 'medico4@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(5, 'Ana', 'Garcia', 'Cardiologia', '965778418', 'medico5@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(6, 'Maria', 'Flores', 'Pediatria', '940878626', 'medico6@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(7, 'Rosa', 'Salazar', 'Medicina General', '907057879', 'medico7@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(8, 'Carmen', 'Medina', 'Traumatologia', '912653523', 'medico8@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(9, 'Lucia', 'Vargas', 'Ginecologia', '942093982', 'medico9@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(10, 'Carlos', 'Quispe', 'Cardiologia', '972509342', 'medico10@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(11, 'Luis', 'Huaman', 'Pediatria', '936264768', 'medico11@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(12, 'Jose', 'Perez', 'Medicina General', '963795817', 'medico12@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(13, 'Juan', 'Rojas', 'Traumatologia', '910184785', 'medico13@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(14, 'Miguel', 'Torres', 'Ginecologia', '959536479', 'medico14@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(15, 'Ana', 'Garcia', 'Cardiologia', '967128043', 'medico15@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(16, 'Maria', 'Flores', 'Pediatria', '957030783', 'medico16@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(17, 'Rosa', 'Salazar', 'Medicina General', '983769788', 'medico17@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(18, 'Carmen', 'Medina', 'Traumatologia', '947756596', 'medico18@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(19, 'Lucia', 'Vargas', 'Ginecologia', '987473619', 'medico19@clinica.pe', 'Lunes a Viernes 08:00 - 14:00'),
(20, 'Carlos', 'Quispe', 'Cardiologia', '994098310', 'medico20@clinica.pe', 'Lunes a Viernes 08:00 - 14:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `ID_PACIENTE` int(11) NOT NULL,
  `NOMBRES` varchar(60) NOT NULL,
  `APELLIDOS` varchar(60) NOT NULL,
  `DNI` varchar(20) NOT NULL,
  `FECHA_NACIMIENTO` date NOT NULL,
  `TELEFONO` varchar(30) NOT NULL,
  `DIRECCION` varchar(120) NOT NULL,
  `CORREO` varchar(100) NOT NULL,
  `FECHA_REGISTRO` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`ID_PACIENTE`, `NOMBRES`, `APELLIDOS`, `DNI`, `FECHA_NACIMIENTO`, `TELEFONO`, `DIRECCION`, `CORREO`, `FECHA_REGISTRO`) VALUES
(1, 'Maria', 'Perez', '70000001', '2006-12-14', '914583976', 'Av. Los Alamos 2', 'paciente1@correo.com', '2025-12-14 13:38:29'),
(2, 'Pedro', 'Rojas', '70000002', '2005-12-14', '916091370', 'Av. Los Alamos 3', 'paciente2@correo.com', '2025-12-14 13:38:29'),
(3, 'Lucia', 'Torres', '70000003', '2004-12-14', '936704929', 'Av. Los Alamos 4', 'paciente3@correo.com', '2025-12-14 13:38:29'),
(4, 'Carlos', 'Huaman', '70000004', '2003-12-14', '935250536', 'Av. Los Alamos 5', 'paciente4@correo.com', '2025-12-14 13:38:29'),
(5, 'Rosa', 'Flores', '70000005', '2002-12-14', '966137898', 'Av. Los Alamos 6', 'paciente5@correo.com', '2025-12-14 13:38:29'),
(6, 'Miguel', 'Garcia', '70000006', '2001-12-14', '924937885', 'Av. Los Alamos 7', 'paciente6@correo.com', '2025-12-14 13:38:29'),
(7, 'Ana', 'Salazar', '70000007', '2000-12-14', '926275735', 'Av. Los Alamos 8', 'paciente7@correo.com', '2025-12-14 13:38:29'),
(8, 'Luis', 'Medina', '70000008', '1999-12-14', '956565023', 'Av. Los Alamos 9', 'paciente8@correo.com', '2025-12-14 13:38:29'),
(9, 'Carmen', 'Vargas', '70000009', '1998-12-14', '903997913', 'Av. Los Alamos 10', 'paciente9@correo.com', '2025-12-14 13:38:29'),
(10, 'Juan', 'Quispe', '70000010', '1997-12-14', '950294499', 'Av. Los Alamos 11', 'paciente10@correo.com', '2025-12-14 13:38:29'),
(11, 'Maria', 'Perez', '70000011', '1996-12-14', '939478761', 'Av. Los Alamos 12', 'paciente11@correo.com', '2025-12-14 13:38:29'),
(12, 'Pedro', 'Rojas', '70000012', '1995-12-14', '946510312', 'Av. Los Alamos 13', 'paciente12@correo.com', '2025-12-14 13:38:29'),
(13, 'Lucia', 'Torres', '70000013', '1994-12-14', '914115281', 'Av. Los Alamos 14', 'paciente13@correo.com', '2025-12-14 13:38:29'),
(14, 'Carlos', 'Huaman', '70000014', '1993-12-14', '931045470', 'Av. Los Alamos 15', 'paciente14@correo.com', '2025-12-14 13:38:29'),
(15, 'Rosa', 'Flores', '70000015', '1992-12-14', '912881513', 'Av. Los Alamos 16', 'paciente15@correo.com', '2025-12-14 13:38:29'),
(16, 'Miguel', 'Garcia', '70000016', '1991-12-14', '971271158', 'Av. Los Alamos 17', 'paciente16@correo.com', '2025-12-14 13:38:29'),
(17, 'Ana', 'Salazar', '70000017', '1990-12-14', '917711255', 'Av. Los Alamos 18', 'paciente17@correo.com', '2025-12-14 13:38:29'),
(18, 'Luis', 'Medina', '70000018', '1989-12-14', '974742806', 'Av. Los Alamos 19', 'paciente18@correo.com', '2025-12-14 13:38:29'),
(19, 'Carmen', 'Vargas', '70000019', '1988-12-14', '920580267', 'Av. Los Alamos 20', 'paciente19@correo.com', '2025-12-14 13:38:29'),
(20, 'Juan', 'Quispe', '70000020', '1987-12-14', '978672920', 'Av. Los Alamos 21', 'paciente20@correo.com', '2025-12-14 13:38:29'),
(21, 'Maria', 'Perez', '70000021', '1986-12-14', '931623804', 'Av. Los Alamos 22', 'paciente21@correo.com', '2025-12-14 13:38:29'),
(22, 'Pedro', 'Rojas', '70000022', '1985-12-14', '922100263', 'Av. Los Alamos 23', 'paciente22@correo.com', '2025-12-14 13:38:29'),
(23, 'Lucia', 'Torres', '70000023', '1984-12-14', '915629906', 'Av. Los Alamos 24', 'paciente23@correo.com', '2025-12-14 13:38:29'),
(24, 'Carlos', 'Huaman', '70000024', '1983-12-14', '911848747', 'Av. Los Alamos 25', 'paciente24@correo.com', '2025-12-14 13:38:29'),
(25, 'Rosa', 'Flores', '70000025', '1982-12-14', '912354019', 'Av. Los Alamos 26', 'paciente25@correo.com', '2025-12-14 13:38:29'),
(26, 'Miguel', 'Garcia', '70000026', '1981-12-14', '926223858', 'Av. Los Alamos 27', 'paciente26@correo.com', '2025-12-14 13:38:29'),
(27, 'Ana', 'Salazar', '70000027', '1980-12-14', '994057235', 'Av. Los Alamos 28', 'paciente27@correo.com', '2025-12-14 13:38:29'),
(28, 'Luis', 'Medina', '70000028', '1979-12-14', '991614604', 'Av. Los Alamos 29', 'paciente28@correo.com', '2025-12-14 13:38:29'),
(29, 'Carmen', 'Vargas', '70000029', '1978-12-14', '975901319', 'Av. Los Alamos 30', 'paciente29@correo.com', '2025-12-14 13:38:29'),
(30, 'Juan', 'Quispe', '70000030', '1977-12-14', '904662787', 'Av. Los Alamos 31', 'paciente30@correo.com', '2025-12-14 13:38:29'),
(31, 'Maria', 'Perez', '70000031', '1976-12-14', '995609982', 'Av. Los Alamos 32', 'paciente31@correo.com', '2025-12-14 13:38:29'),
(32, 'Pedro', 'Rojas', '70000032', '1975-12-14', '964061553', 'Av. Los Alamos 33', 'paciente32@correo.com', '2025-12-14 13:38:29'),
(33, 'Lucia', 'Torres', '70000033', '1974-12-14', '933477822', 'Av. Los Alamos 34', 'paciente33@correo.com', '2025-12-14 13:38:29'),
(34, 'Carlos', 'Huaman', '70000034', '1973-12-14', '975204456', 'Av. Los Alamos 35', 'paciente34@correo.com', '2025-12-14 13:38:29'),
(35, 'Rosa', 'Flores', '70000035', '1972-12-14', '975588817', 'Av. Los Alamos 36', 'paciente35@correo.com', '2025-12-14 13:38:29'),
(36, 'Miguel', 'Garcia', '70000036', '1971-12-14', '952330718', 'Av. Los Alamos 37', 'paciente36@correo.com', '2025-12-14 13:38:29'),
(37, 'Ana', 'Salazar', '70000037', '1970-12-14', '934887145', 'Av. Los Alamos 38', 'paciente37@correo.com', '2025-12-14 13:38:29'),
(38, 'Luis', 'Medina', '70000038', '1969-12-14', '917443576', 'Av. Los Alamos 39', 'paciente38@correo.com', '2025-12-14 13:38:29'),
(39, 'Carmen', 'Vargas', '70000039', '1968-12-14', '982556447', 'Av. Los Alamos 40', 'paciente39@correo.com', '2025-12-14 13:38:29'),
(40, 'Juan', 'Quispe', '70000040', '1967-12-14', '960451511', 'Av. Los Alamos 41', 'paciente40@correo.com', '2025-12-14 13:38:29'),
(41, 'Maria', 'Perez', '70000041', '1966-12-14', '954588217', 'Av. Los Alamos 42', 'paciente41@correo.com', '2025-12-14 13:38:29'),
(42, 'Pedro', 'Rojas', '70000042', '1965-12-14', '991586556', 'Av. Los Alamos 43', 'paciente42@correo.com', '2025-12-14 13:38:29'),
(43, 'Lucia', 'Torres', '70000043', '1964-12-14', '994168134', 'Av. Los Alamos 44', 'paciente43@correo.com', '2025-12-14 13:38:29'),
(44, 'Carlos', 'Huaman', '70000044', '1963-12-14', '996081004', 'Av. Los Alamos 45', 'paciente44@correo.com', '2025-12-14 13:38:29'),
(45, 'Rosa', 'Flores', '70000045', '1962-12-14', '997900622', 'Av. Los Alamos 46', 'paciente45@correo.com', '2025-12-14 13:38:29'),
(46, 'Miguel', 'Garcia', '70000046', '1961-12-14', '901260102', 'Av. Los Alamos 47', 'paciente46@correo.com', '2025-12-14 13:38:29'),
(47, 'Ana', 'Salazar', '70000047', '1960-12-14', '912598649', 'Av. Los Alamos 48', 'paciente47@correo.com', '2025-12-14 13:38:29'),
(48, 'Luis', 'Medina', '70000048', '1959-12-14', '959212941', 'Av. Los Alamos 49', 'paciente48@correo.com', '2025-12-14 13:38:29'),
(49, 'Carmen', 'Vargas', '70000049', '1958-12-14', '958268764', 'Av. Los Alamos 50', 'paciente49@correo.com', '2025-12-14 13:38:29'),
(50, 'Juan', 'Quispe', '70000050', '2007-12-14', '913704997', 'Av. Los Alamos 1', 'paciente50@correo.com', '2025-12-14 13:38:29'),
(51, 'Maria', 'Perez', '70000051', '2006-12-14', '993718700', 'Av. Los Alamos 2', 'paciente51@correo.com', '2025-12-14 13:38:29'),
(52, 'Pedro', 'Rojas', '70000052', '2005-12-14', '927478509', 'Av. Los Alamos 3', 'paciente52@correo.com', '2025-12-14 13:38:29'),
(53, 'Lucia', 'Torres', '70000053', '2004-12-14', '956236452', 'Av. Los Alamos 4', 'paciente53@correo.com', '2025-12-14 13:38:29'),
(54, 'Carlos', 'Huaman', '70000054', '2003-12-14', '998746736', 'Av. Los Alamos 5', 'paciente54@correo.com', '2025-12-14 13:38:29'),
(55, 'Rosa', 'Flores', '70000055', '2002-12-14', '925024327', 'Av. Los Alamos 6', 'paciente55@correo.com', '2025-12-14 13:38:29'),
(56, 'Miguel', 'Garcia', '70000056', '2001-12-14', '928881430', 'Av. Los Alamos 7', 'paciente56@correo.com', '2025-12-14 13:38:29'),
(57, 'Ana', 'Salazar', '70000057', '2000-12-14', '969334172', 'Av. Los Alamos 8', 'paciente57@correo.com', '2025-12-14 13:38:29'),
(58, 'Luis', 'Medina', '70000058', '1999-12-14', '960026573', 'Av. Los Alamos 9', 'paciente58@correo.com', '2025-12-14 13:38:29'),
(59, 'Carmen', 'Vargas', '70000059', '1998-12-14', '992130352', 'Av. Los Alamos 10', 'paciente59@correo.com', '2025-12-14 13:38:29'),
(60, 'Juan', 'Quispe', '70000060', '1997-12-14', '980572047', 'Av. Los Alamos 11', 'paciente60@correo.com', '2025-12-14 13:38:29'),
(61, 'Maria', 'Perez', '70000061', '1996-12-14', '926469183', 'Av. Los Alamos 12', 'paciente61@correo.com', '2025-12-14 13:38:29'),
(62, 'Pedro', 'Rojas', '70000062', '1995-12-14', '990629778', 'Av. Los Alamos 13', 'paciente62@correo.com', '2025-12-14 13:38:29'),
(63, 'Lucia', 'Torres', '70000063', '1994-12-14', '973741344', 'Av. Los Alamos 14', 'paciente63@correo.com', '2025-12-14 13:38:29'),
(64, 'Carlos', 'Huaman', '70000064', '1993-12-14', '996817388', 'Av. Los Alamos 15', 'paciente64@correo.com', '2025-12-14 13:38:29'),
(65, 'Rosa', 'Flores', '70000065', '1992-12-14', '962862912', 'Av. Los Alamos 16', 'paciente65@correo.com', '2025-12-14 13:38:29'),
(66, 'Miguel', 'Garcia', '70000066', '1991-12-14', '923862398', 'Av. Los Alamos 17', 'paciente66@correo.com', '2025-12-14 13:38:29'),
(67, 'Ana', 'Salazar', '70000067', '1990-12-14', '930723259', 'Av. Los Alamos 18', 'paciente67@correo.com', '2025-12-14 13:38:29'),
(68, 'Luis', 'Medina', '70000068', '1989-12-14', '982029105', 'Av. Los Alamos 19', 'paciente68@correo.com', '2025-12-14 13:38:29'),
(69, 'Carmen', 'Vargas', '70000069', '1988-12-14', '917975750', 'Av. Los Alamos 20', 'paciente69@correo.com', '2025-12-14 13:38:29'),
(70, 'Juan', 'Quispe', '70000070', '1987-12-14', '943791438', 'Av. Los Alamos 21', 'paciente70@correo.com', '2025-12-14 13:38:29'),
(71, 'Maria', 'Perez', '70000071', '1986-12-14', '965029945', 'Av. Los Alamos 22', 'paciente71@correo.com', '2025-12-14 13:38:29'),
(72, 'Pedro', 'Rojas', '70000072', '1985-12-14', '993775416', 'Av. Los Alamos 23', 'paciente72@correo.com', '2025-12-14 13:38:29'),
(73, 'Lucia', 'Torres', '70000073', '1984-12-14', '973787246', 'Av. Los Alamos 24', 'paciente73@correo.com', '2025-12-14 13:38:29'),
(74, 'Carlos', 'Huaman', '70000074', '1983-12-14', '987609988', 'Av. Los Alamos 25', 'paciente74@correo.com', '2025-12-14 13:38:29'),
(75, 'Rosa', 'Flores', '70000075', '1982-12-14', '916688204', 'Av. Los Alamos 26', 'paciente75@correo.com', '2025-12-14 13:38:29'),
(76, 'Miguel', 'Garcia', '70000076', '1981-12-14', '920611059', 'Av. Los Alamos 27', 'paciente76@correo.com', '2025-12-14 13:38:29'),
(77, 'Ana', 'Salazar', '70000077', '1980-12-14', '952990689', 'Av. Los Alamos 28', 'paciente77@correo.com', '2025-12-14 13:38:29'),
(78, 'Luis', 'Medina', '70000078', '1979-12-14', '903120271', 'Av. Los Alamos 29', 'paciente78@correo.com', '2025-12-14 13:38:29'),
(79, 'Carmen', 'Vargas', '70000079', '1978-12-14', '956629293', 'Av. Los Alamos 30', 'paciente79@correo.com', '2025-12-14 13:38:29'),
(80, 'Juan', 'Quispe', '70000080', '1977-12-14', '973785653', 'Av. Los Alamos 31', 'paciente80@correo.com', '2025-12-14 13:38:29'),
(81, 'Maria', 'Perez', '70000081', '1976-12-14', '999040390', 'Av. Los Alamos 32', 'paciente81@correo.com', '2025-12-14 13:38:29'),
(82, 'Pedro', 'Rojas', '70000082', '1975-12-14', '973844995', 'Av. Los Alamos 33', 'paciente82@correo.com', '2025-12-14 13:38:29'),
(83, 'Lucia', 'Torres', '70000083', '1974-12-14', '972103809', 'Av. Los Alamos 34', 'paciente83@correo.com', '2025-12-14 13:38:29'),
(84, 'Carlos', 'Huaman', '70000084', '1973-12-14', '938984063', 'Av. Los Alamos 35', 'paciente84@correo.com', '2025-12-14 13:38:29'),
(85, 'Rosa', 'Flores', '70000085', '1972-12-14', '978608892', 'Av. Los Alamos 36', 'paciente85@correo.com', '2025-12-14 13:38:29'),
(86, 'Miguel', 'Garcia', '70000086', '1971-12-14', '976092273', 'Av. Los Alamos 37', 'paciente86@correo.com', '2025-12-14 13:38:29'),
(87, 'Ana', 'Salazar', '70000087', '1970-12-14', '944634694', 'Av. Los Alamos 38', 'paciente87@correo.com', '2025-12-14 13:38:29'),
(88, 'Luis', 'Medina', '70000088', '1969-12-14', '994896653', 'Av. Los Alamos 39', 'paciente88@correo.com', '2025-12-14 13:38:29'),
(89, 'Carmen', 'Vargas', '70000089', '1968-12-14', '940579187', 'Av. Los Alamos 40', 'paciente89@correo.com', '2025-12-14 13:38:29'),
(90, 'Juan', 'Quispe', '70000090', '1967-12-14', '918205980', 'Av. Los Alamos 41', 'paciente90@correo.com', '2025-12-14 13:38:29'),
(91, 'Maria', 'Perez', '70000091', '1966-12-14', '969292341', 'Av. Los Alamos 42', 'paciente91@correo.com', '2025-12-14 13:38:29'),
(92, 'Pedro', 'Rojas', '70000092', '1965-12-14', '991843769', 'Av. Los Alamos 43', 'paciente92@correo.com', '2025-12-14 13:38:29'),
(93, 'Lucia', 'Torres', '70000093', '1964-12-14', '951341827', 'Av. Los Alamos 44', 'paciente93@correo.com', '2025-12-14 13:38:29'),
(94, 'Carlos', 'Huaman', '70000094', '1963-12-14', '981177832', 'Av. Los Alamos 45', 'paciente94@correo.com', '2025-12-14 13:38:29'),
(95, 'Rosa', 'Flores', '70000095', '1962-12-14', '951863681', 'Av. Los Alamos 46', 'paciente95@correo.com', '2025-12-14 13:38:29'),
(96, 'Miguel', 'Garcia', '70000096', '1961-12-14', '915784914', 'Av. Los Alamos 47', 'paciente96@correo.com', '2025-12-14 13:38:29'),
(97, 'Ana', 'Salazar', '70000097', '1960-12-14', '923333529', 'Av. Los Alamos 48', 'paciente97@correo.com', '2025-12-14 13:38:29'),
(98, 'Luis', 'Medina', '70000098', '1959-12-14', '969312908', 'Av. Los Alamos 49', 'paciente98@correo.com', '2025-12-14 13:38:29'),
(99, 'Carmen', 'Vargas', '70000099', '1958-12-14', '976563958', 'Av. Los Alamos 50', 'paciente99@correo.com', '2025-12-14 13:38:29'),
(100, 'Juan', 'Quispe', '70000100', '2007-12-14', '974881068', 'Av. Los Alamos 1', 'paciente100@correo.com', '2025-12-14 13:38:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `ID_PAGO` int(11) NOT NULL,
  `ID_CITA` int(11) NOT NULL,
  `MONTO` decimal(8,2) NOT NULL,
  `TIPO_PAGO` varchar(20) NOT NULL,
  `FECHA_PAGO` datetime NOT NULL,
  `CODIGO_COMPROBANTE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`ID_PAGO`, `ID_CITA`, `MONTO`, `TIPO_PAGO`, `FECHA_PAGO`, `CODIGO_COMPROBANTE`) VALUES
(64, 258, 86.83, 'TARJETA', '2025-12-14 13:40:57', 'CP-258'),
(65, 262, 68.29, 'YAPE', '2025-12-14 13:40:57', 'CP-262'),
(66, 266, 56.07, 'TARJETA', '2025-12-14 13:40:57', 'CP-266'),
(67, 268, 90.79, 'TARJETA', '2025-12-14 13:40:57', 'CP-268'),
(68, 270, 60.33, 'YAPE', '2025-12-14 13:40:57', 'CP-270'),
(69, 271, 69.14, 'TARJETA', '2025-12-14 13:40:57', 'CP-271'),
(70, 283, 110.63, 'YAPE', '2025-12-14 13:40:57', 'CP-283'),
(71, 286, 119.67, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-286'),
(72, 287, 118.01, 'YAPE', '2025-12-14 13:40:57', 'CP-287'),
(73, 295, 105.26, 'YAPE', '2025-12-14 13:40:57', 'CP-295'),
(74, 296, 77.77, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-296'),
(75, 297, 70.29, 'TARJETA', '2025-12-14 13:40:57', 'CP-297'),
(76, 303, 75.62, 'YAPE', '2025-12-14 13:40:57', 'CP-303'),
(77, 307, 44.07, 'YAPE', '2025-12-14 13:40:57', 'CP-307'),
(78, 308, 96.72, 'TARJETA', '2025-12-14 13:40:57', 'CP-308'),
(79, 309, 81.06, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-309'),
(80, 313, 109.71, 'YAPE', '2025-12-14 13:40:57', 'CP-313'),
(81, 316, 95.01, 'YAPE', '2025-12-14 13:40:57', 'CP-316'),
(82, 318, 57.70, 'YAPE', '2025-12-14 13:40:57', 'CP-318'),
(83, 324, 81.19, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-324'),
(84, 325, 63.40, 'YAPE', '2025-12-14 13:40:57', 'CP-325'),
(85, 330, 113.85, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-330'),
(86, 332, 132.56, 'TARJETA', '2025-12-14 13:40:57', 'CP-332'),
(87, 333, 133.90, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-333'),
(88, 334, 91.18, 'TARJETA', '2025-12-14 13:40:57', 'CP-334'),
(89, 335, 67.22, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-335'),
(90, 337, 96.54, 'YAPE', '2025-12-14 13:40:57', 'CP-337'),
(91, 342, 69.25, 'TARJETA', '2025-12-14 13:40:57', 'CP-342'),
(92, 348, 86.94, 'YAPE', '2025-12-14 13:40:57', 'CP-348'),
(93, 349, 68.64, 'TARJETA', '2025-12-14 13:40:57', 'CP-349'),
(94, 350, 61.70, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-350'),
(95, 353, 94.59, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-353'),
(96, 354, 81.94, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-354'),
(97, 355, 45.47, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-355'),
(98, 364, 66.53, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-364'),
(99, 368, 94.89, 'TARJETA', '2025-12-14 13:40:57', 'CP-368'),
(100, 372, 44.13, 'TARJETA', '2025-12-14 13:40:57', 'CP-372'),
(101, 373, 124.37, 'TARJETA', '2025-12-14 13:40:57', 'CP-373'),
(102, 376, 105.96, 'YAPE', '2025-12-14 13:40:57', 'CP-376'),
(103, 377, 133.95, 'YAPE', '2025-12-14 13:40:57', 'CP-377'),
(104, 381, 131.31, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-381'),
(105, 382, 129.41, 'TARJETA', '2025-12-14 13:40:57', 'CP-382'),
(106, 383, 117.02, 'TARJETA', '2025-12-14 13:40:57', 'CP-383'),
(107, 388, 98.67, 'YAPE', '2025-12-14 13:40:57', 'CP-388'),
(108, 390, 61.54, 'YAPE', '2025-12-14 13:40:57', 'CP-390'),
(109, 394, 121.24, 'YAPE', '2025-12-14 13:40:57', 'CP-394'),
(110, 396, 89.68, 'TARJETA', '2025-12-14 13:40:57', 'CP-396'),
(111, 397, 52.74, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-397'),
(112, 398, 134.92, 'TARJETA', '2025-12-14 13:40:57', 'CP-398'),
(113, 400, 128.85, 'YAPE', '2025-12-14 13:40:57', 'CP-400'),
(114, 410, 73.82, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-410'),
(115, 412, 82.86, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-412'),
(116, 416, 50.08, 'YAPE', '2025-12-14 13:40:57', 'CP-416'),
(117, 418, 45.77, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-418'),
(118, 423, 58.99, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-423'),
(119, 424, 48.80, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-424'),
(120, 426, 136.30, 'YAPE', '2025-12-14 13:40:57', 'CP-426'),
(121, 432, 90.52, 'TARJETA', '2025-12-14 13:40:57', 'CP-432'),
(122, 433, 133.20, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-433'),
(123, 435, 56.18, 'EFECTIVO', '2025-12-14 13:40:57', 'CP-435'),
(124, 436, 108.56, 'YAPE', '2025-12-14 13:40:57', 'CP-436'),
(125, 444, 96.96, 'YAPE', '2025-12-14 13:40:57', 'CP-444');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion`
--

CREATE TABLE `sesion` (
  `ID_SECCION` int(11) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  `FECHA_I_S` datetime NOT NULL,
  `FECHA_F_S` datetime NOT NULL,
  `TOCKEN_S` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sesion`
--

INSERT INTO `sesion` (`ID_SECCION`, `ID_USUARIO`, `FECHA_I_S`, `FECHA_F_S`, `TOCKEN_S`) VALUES
(387, 543, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b25fb76-d91c-11f0-a70a-088fc31d04a4'),
(388, 544, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b26055d-d91c-11f0-a70a-088fc31d04a4'),
(389, 545, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b260606-d91c-11f0-a70a-088fc31d04a4'),
(390, 546, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b260657-d91c-11f0-a70a-088fc31d04a4'),
(391, 547, '2025-12-13 13:39:32', '2025-12-14 13:39:32', '3b2606a3-d91c-11f0-a70a-088fc31d04a4'),
(392, 548, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b2606e9-d91c-11f0-a70a-088fc31d04a4'),
(393, 549, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b26072f-d91c-11f0-a70a-088fc31d04a4'),
(394, 550, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b26076f-d91c-11f0-a70a-088fc31d04a4'),
(395, 551, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b2607bc-d91c-11f0-a70a-088fc31d04a4'),
(396, 552, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b260833-d91c-11f0-a70a-088fc31d04a4'),
(397, 553, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b260878-d91c-11f0-a70a-088fc31d04a4'),
(398, 554, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b267186-d91c-11f0-a70a-088fc31d04a4'),
(399, 555, '2025-12-13 13:39:32', '2025-12-14 13:39:32', '3b267312-d91c-11f0-a70a-088fc31d04a4'),
(400, 556, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b267388-d91c-11f0-a70a-088fc31d04a4'),
(401, 557, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b2673f7-d91c-11f0-a70a-088fc31d04a4'),
(402, 558, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b267455-d91c-11f0-a70a-088fc31d04a4'),
(403, 559, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b2674cc-d91c-11f0-a70a-088fc31d04a4'),
(404, 560, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b267703-d91c-11f0-a70a-088fc31d04a4'),
(405, 561, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b267766-d91c-11f0-a70a-088fc31d04a4'),
(406, 562, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b2677c1-d91c-11f0-a70a-088fc31d04a4'),
(407, 563, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b26782b-d91c-11f0-a70a-088fc31d04a4'),
(408, 564, '2025-12-13 13:39:32', '2025-12-14 13:39:32', '3b26786e-d91c-11f0-a70a-088fc31d04a4'),
(409, 565, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b2678ad-d91c-11f0-a70a-088fc31d04a4'),
(410, 566, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b26797f-d91c-11f0-a70a-088fc31d04a4'),
(411, 567, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b2679bf-d91c-11f0-a70a-088fc31d04a4'),
(412, 568, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b2679fb-d91c-11f0-a70a-088fc31d04a4'),
(413, 569, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b267a38-d91c-11f0-a70a-088fc31d04a4'),
(414, 570, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b267a75-d91c-11f0-a70a-088fc31d04a4'),
(415, 571, '2025-12-13 13:39:32', '2025-12-14 13:39:32', '3b267ab2-d91c-11f0-a70a-088fc31d04a4'),
(416, 572, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b267aee-d91c-11f0-a70a-088fc31d04a4'),
(417, 573, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b267b2a-d91c-11f0-a70a-088fc31d04a4'),
(418, 574, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b267b68-d91c-11f0-a70a-088fc31d04a4'),
(419, 575, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b267bae-d91c-11f0-a70a-088fc31d04a4'),
(420, 576, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b267bea-d91c-11f0-a70a-088fc31d04a4'),
(421, 577, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b267c26-d91c-11f0-a70a-088fc31d04a4'),
(422, 578, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b267c63-d91c-11f0-a70a-088fc31d04a4'),
(423, 579, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b267ca2-d91c-11f0-a70a-088fc31d04a4'),
(424, 580, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b267cdf-d91c-11f0-a70a-088fc31d04a4'),
(425, 581, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b267d1b-d91c-11f0-a70a-088fc31d04a4'),
(426, 582, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b267d58-d91c-11f0-a70a-088fc31d04a4'),
(427, 583, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b267d96-d91c-11f0-a70a-088fc31d04a4'),
(428, 584, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b267dd2-d91c-11f0-a70a-088fc31d04a4'),
(429, 585, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b267e11-d91c-11f0-a70a-088fc31d04a4'),
(430, 586, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b267e4d-d91c-11f0-a70a-088fc31d04a4'),
(431, 587, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b267e8b-d91c-11f0-a70a-088fc31d04a4'),
(432, 588, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b267ec7-d91c-11f0-a70a-088fc31d04a4'),
(433, 589, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b267f04-d91c-11f0-a70a-088fc31d04a4'),
(434, 590, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b267f40-d91c-11f0-a70a-088fc31d04a4'),
(435, 591, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b267f7e-d91c-11f0-a70a-088fc31d04a4'),
(436, 592, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b267fbb-d91c-11f0-a70a-088fc31d04a4'),
(437, 593, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b267ff7-d91c-11f0-a70a-088fc31d04a4'),
(438, 594, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b268033-d91c-11f0-a70a-088fc31d04a4'),
(439, 595, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b268070-d91c-11f0-a70a-088fc31d04a4'),
(440, 596, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b2680ac-d91c-11f0-a70a-088fc31d04a4'),
(441, 597, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b2680e9-d91c-11f0-a70a-088fc31d04a4'),
(442, 598, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b268126-d91c-11f0-a70a-088fc31d04a4'),
(443, 599, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b268165-d91c-11f0-a70a-088fc31d04a4'),
(444, 600, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b2681a2-d91c-11f0-a70a-088fc31d04a4'),
(445, 601, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b2681e0-d91c-11f0-a70a-088fc31d04a4'),
(446, 602, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b26821c-d91c-11f0-a70a-088fc31d04a4'),
(447, 603, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b26825b-d91c-11f0-a70a-088fc31d04a4'),
(448, 604, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b268297-d91c-11f0-a70a-088fc31d04a4'),
(449, 605, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b2682d3-d91c-11f0-a70a-088fc31d04a4'),
(450, 606, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b268310-d91c-11f0-a70a-088fc31d04a4'),
(451, 607, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b268352-d91c-11f0-a70a-088fc31d04a4'),
(452, 608, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b268390-d91c-11f0-a70a-088fc31d04a4'),
(453, 609, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b2683cc-d91c-11f0-a70a-088fc31d04a4'),
(454, 610, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b268407-d91c-11f0-a70a-088fc31d04a4'),
(455, 611, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b268446-d91c-11f0-a70a-088fc31d04a4'),
(456, 612, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b268483-d91c-11f0-a70a-088fc31d04a4'),
(457, 613, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b2684bf-d91c-11f0-a70a-088fc31d04a4'),
(458, 614, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b2684fb-d91c-11f0-a70a-088fc31d04a4'),
(459, 615, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b26853b-d91c-11f0-a70a-088fc31d04a4'),
(460, 616, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b268576-d91c-11f0-a70a-088fc31d04a4'),
(461, 617, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b2685b4-d91c-11f0-a70a-088fc31d04a4'),
(462, 618, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b2685f1-d91c-11f0-a70a-088fc31d04a4'),
(463, 619, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b26862f-d91c-11f0-a70a-088fc31d04a4'),
(464, 620, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b26866b-d91c-11f0-a70a-088fc31d04a4'),
(465, 621, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b2686a7-d91c-11f0-a70a-088fc31d04a4'),
(466, 622, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b2686e4-d91c-11f0-a70a-088fc31d04a4'),
(467, 623, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b268722-d91c-11f0-a70a-088fc31d04a4'),
(468, 624, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b26875e-d91c-11f0-a70a-088fc31d04a4'),
(469, 625, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b26879a-d91c-11f0-a70a-088fc31d04a4'),
(470, 626, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b2687d7-d91c-11f0-a70a-088fc31d04a4'),
(471, 627, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b268815-d91c-11f0-a70a-088fc31d04a4'),
(472, 628, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b268851-d91c-11f0-a70a-088fc31d04a4'),
(473, 629, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b26888d-d91c-11f0-a70a-088fc31d04a4'),
(474, 630, '2025-12-14 13:39:32', '2025-12-14 13:39:32', '3b2688c9-d91c-11f0-a70a-088fc31d04a4'),
(475, 631, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b268907-d91c-11f0-a70a-088fc31d04a4'),
(476, 632, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b268942-d91c-11f0-a70a-088fc31d04a4'),
(477, 633, '2025-12-13 13:39:32', '2025-12-14 13:39:32', '3b26897f-d91c-11f0-a70a-088fc31d04a4'),
(478, 634, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b2689bb-d91c-11f0-a70a-088fc31d04a4'),
(479, 635, '2025-12-09 13:39:32', '2025-12-14 13:39:32', '3b2689f8-d91c-11f0-a70a-088fc31d04a4'),
(480, 636, '2025-12-11 13:39:32', '2025-12-14 13:39:32', '3b268a34-d91c-11f0-a70a-088fc31d04a4'),
(481, 637, '2025-12-05 13:39:32', '2025-12-14 13:39:32', '3b268a71-d91c-11f0-a70a-088fc31d04a4'),
(482, 638, '2025-12-07 13:39:32', '2025-12-14 13:39:32', '3b268aae-d91c-11f0-a70a-088fc31d04a4'),
(483, 639, '2025-12-06 13:39:32', '2025-12-14 13:39:32', '3b268aec-d91c-11f0-a70a-088fc31d04a4'),
(484, 640, '2025-12-12 13:39:32', '2025-12-14 13:39:32', '3b268b28-d91c-11f0-a70a-088fc31d04a4'),
(485, 641, '2025-12-10 13:39:32', '2025-12-14 13:39:32', '3b268b64-d91c-11f0-a70a-088fc31d04a4'),
(486, 642, '2025-12-08 13:39:32', '2025-12-14 13:39:32', '3b268ba0-d91c-11f0-a70a-088fc31d04a4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID_USUARIO` int(11) NOT NULL,
  `ID_MEDICO` int(11) DEFAULT NULL,
  `NOM_USUARIO` varchar(40) NOT NULL,
  `CONTRA_HASH` varchar(200) NOT NULL,
  `ROL` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_USUARIO`, `ID_MEDICO`, `NOM_USUARIO`, `CONTRA_HASH`, `ROL`) VALUES
(543, NULL, 'usuario_1', '9010e72389a80487d473017425c6ec7951068abed82a4df32459c91f0e45d2ea', 'ADMIN'),
(544, NULL, 'usuario_2', '998aab960cd9f809b09dd12eade1de4a2985f62335d8ff45a775a598ead09b06', 'ADMIN'),
(545, NULL, 'usuario_3', 'ebeaace31a258620999e9fba185031b757451d37dd76b3bea25c5b897bb46be4', 'ADMIN'),
(546, NULL, 'usuario_4', 'ae84504e96e41376c2b23e773fc66a6689f60bdd3f68a0909c4a4ccaa554fb2b', 'ADMIN'),
(547, NULL, 'usuario_5', 'ae4379b9e5aed205fb7a1e6899aaaf7fa1a38d03031bf116331454fc99d02d56', 'ADMIN'),
(548, NULL, 'usuario_6', '89110cc12704c37be4a619fcc714bf215bedf8ebfc73d53d8ea48c508dd35598', 'ADMIN'),
(549, NULL, 'usuario_7', '9f4f6119ace4c7bc452c0ae26772417a55228289880e4e60846278fb356e2a6d', 'ADMIN'),
(550, NULL, 'usuario_8', '0e07d5a94ae1213f0cc1deab861ffc695d25a150d1b003b601f65c035806cf3d', 'ADMIN'),
(551, NULL, 'usuario_9', 'f9b7c3f80dc882752ecd5b94c6118e6065c3ec5fa9ecc3729caeca6b5bf63ef3', 'ADMIN'),
(552, NULL, 'usuario_10', '178193593da688d2f7dfdf7bb61de0d31174af15068a1c837595f966bc69b0ee', 'ADMIN'),
(553, NULL, 'usuario_11', 'fa69cdc737cda8b1adc169cf6b850a0492750a713b9c3c92d411437b36f2e191', 'ADMIN'),
(554, NULL, 'usuario_12', '798d9f8bf1d51bc056e96fc69436b93da1a6e63b0237bb8b2eb5848e9ca9a7e4', 'ADMIN'),
(555, NULL, 'usuario_13', '3f01d5365c9835c12867a11f3ca3f8e2f40f3c0e00d64417ecc43d143562c038', 'ADMIN'),
(556, NULL, 'usuario_14', '73c73b3e3d5e6f21d285e52a1de82b151d04ffea7ee3fdf36e7aec34ed54584a', 'ADMIN'),
(557, NULL, 'usuario_15', 'b7a7c78ade5341f9ae365d07de8ab9ee6269f5bdb62543ba90fec69558efa3e6', 'ADMIN'),
(558, NULL, 'usuario_16', '96a629018f92903553991418cb78d864718f80a075856da6e78fe564fb8f80da', 'ADMIN'),
(559, NULL, 'usuario_17', '22e947513f94d30eae7b5c5225badb018d9d36afd24d2839b7926faa0150c9d0', 'ADMIN'),
(560, NULL, 'usuario_18', '93916d9ffc21fd0c922d89a1ddef5ae1f2618f83ee4a365598eceb0183d806b5', 'ADMIN'),
(561, NULL, 'usuario_19', 'ac05ed6b41d525f42307f12a9574da9cb70f9fc93efe3114f784c24504279edb', 'ADMIN'),
(562, NULL, 'usuario_20', '319e44233614606e925a45934eb60a80dd9f454f8666d203895f6a6211dd0d26', 'ADMIN'),
(563, NULL, 'usuario_21', 'cf667c11e3c39c775d9004cd127d9e2283df24f03e61f41d8a824972d4f50a79', 'ADMIN'),
(564, NULL, 'usuario_22', 'c7c74711b3febda37df0fe65f5a3c29017b1f8893d1f0335a13a3a6c7b8fc1e0', 'ADMIN'),
(565, NULL, 'usuario_23', 'f7481def5afc18ef542a3fdefe5303633ceec51b20ea46e5de8ee7587bddc3a6', 'ADMIN'),
(566, NULL, 'usuario_24', '45f889adc6ee2d2cff4555beea3c851cbd9aa96199d2d9264e980927147fc482', 'ADMIN'),
(567, NULL, 'usuario_25', '20ce4461cbb11e09499d078497fa29db7b323821a548382aae141ff151065d29', 'ADMIN'),
(568, NULL, 'usuario_26', '1629d76b00948817f836685d32e30cd075351df605196123a3017260dc78c0b7', 'ADMIN'),
(569, NULL, 'usuario_27', 'f660f1adff8eccde2ead2c8ae6c3dd8d5b964fb96ed0bceac5e107ec21c8fd3d', 'ADMIN'),
(570, NULL, 'usuario_28', '8ec1f902ed6ca2b1272190a75a3eb77059da585eff7ee4c6ebb494df93420a3e', 'ADMIN'),
(571, NULL, 'usuario_29', '0b1e682a47427980e9330e92e4b2fd8baad7253c1879f0ebe75cac39cbdd79c7', 'ADMIN'),
(572, NULL, 'usuario_30', '997e62e8d0e09c96f3c0e76614be8c7447bf3fdf25b10747de54a1468a36b49c', 'ADMIN'),
(573, NULL, 'usuario_31', 'ee86d0123201ebb6dd8836a0c2cad7096c9c546aa92b141145141782820e9ff3', 'ADMIN'),
(574, NULL, 'usuario_32', '77e41a90f2dfd24eb21d8bc76945750da99616fc84611270396a91518757e0f9', 'ADMIN'),
(575, NULL, 'usuario_33', '20b42c9783976f75d526ca091d72c4a4660032fdd4b179f9ad07f5edcffce165', 'ADMIN'),
(576, NULL, 'usuario_34', 'a043eb8df62458a646889ea124e541983a36cd707b45cd2a6e099d505a012afe', 'ADMIN'),
(577, NULL, 'usuario_35', 'ec4eb6595e426dfc242f5a611defd1150715f3b4366ffa169840ac78d796d771', 'ADMIN'),
(578, NULL, 'usuario_36', 'b4272fee841ddc077c31dd9f3ee9cacac8628737e1266d624f371bb816eaa353', 'ADMIN'),
(579, NULL, 'usuario_37', '57029cc8f928b45d941392b9fd0bbe6a99b4168e9ea8377bf7b9974c651c12c4', 'ADMIN'),
(580, NULL, 'usuario_38', '1fbc3cf6c231f83e0750a582de1c717cc0697fe5162bb953b5f4eb9facc60975', 'ADMIN'),
(581, NULL, 'usuario_39', '0c0fed5e16b70e36c093cc381a58e182bf71c33844ccc30960fabcec74f7a13b', 'ADMIN'),
(582, NULL, 'usuario_40', '52db22939fc8e73de5ce93e7a2868f309dc79c72174ccca524bb9ed8e7a2ad80', 'ADMIN'),
(583, NULL, 'usuario_41', '04bade11e2f68bd856567cb73f2fab3214852d2c3ddcd13f58a22f3e89d50cfb', 'ADMIN'),
(584, NULL, 'usuario_42', '46254752654d6b33f4fbd1fe7f4c2971ceef5d3e5092b6d0246b8bbeab33722e', 'ADMIN'),
(585, NULL, 'usuario_43', '2ddc22f73a7a1369cdaa28c137d856a55d544c4843081dfb77a8c46408f5f7cd', 'ADMIN'),
(586, NULL, 'usuario_44', '4e292d7a7c26c4dd911466a399be6bf219addb34056227d7a0f196f9c00acfb9', 'ADMIN'),
(587, NULL, 'usuario_45', 'd2b521994e863c10bd51a5747dca8a376bdeb4958f8459983caf40ad1ffa9e18', 'ADMIN'),
(588, NULL, 'usuario_46', '2317b6e5cbfa157fb02afb4cbb060696dede6e05096da6c1f9939b9d28f5e56a', 'ADMIN'),
(589, NULL, 'usuario_47', 'a6410a6343c65d553995b301b2df63d9461631bb713d94177caaddbde65c9f91', 'ADMIN'),
(590, NULL, 'usuario_48', '74a88d36e313d0654c35b246afd949f34bd9f5e221af98a8e98ab7d860b0b500', 'ADMIN'),
(591, NULL, 'usuario_49', '759e3687ee534a479f5524749438ea281e88e58bd0e704a00f818b6c7a445e3c', 'ADMIN'),
(592, NULL, 'usuario_50', '97b6d27b86ce67b2dc1733b3fe77bbb3dddff2ae6b9fa284ec8d43b3416395f2', 'ADMIN'),
(593, NULL, 'usuario_51', '75afdf01252f36c3e0d33712c7ec8c884a89c996bf7a83da25a23ff9ed511a6a', 'ADMIN'),
(594, NULL, 'usuario_52', '52bf8276503f37eeb0428622821cbe0dbc892f47571253ad0148bd3981ecd96a', 'ADMIN'),
(595, NULL, 'usuario_53', '3dc0ac5910627c6faa4e01f4f0cd700f0903731f720b3b673df64c126f718e3e', 'ADMIN'),
(596, NULL, 'usuario_54', 'deb53949c00f6b9b6688bcf0dd8a7d6ce67191c00a49ef25f80173cfddb7e0ed', 'ADMIN'),
(597, NULL, 'usuario_55', '94252f2586be8c4841b923ce313d83e550a0897b0082b7c2b162257606e7d07c', 'ADMIN'),
(598, NULL, 'usuario_56', 'b63d0bc3b0afb870999ef3cd2775e736c3820e8f54858cbd95224e6b6c661ee2', 'ADMIN'),
(599, NULL, 'usuario_57', '5b6d249d59e8357ec025974ebd75d7877b681422808bc726f3b74e45ae5fc7b9', 'ADMIN'),
(600, NULL, 'usuario_58', 'd7b22f04ced96365cd48487c33e303b52c8b813183fd93e6680b4937ee0dd59b', 'ADMIN'),
(601, NULL, 'usuario_59', 'a53943af87f91fa9a48871afffee5863d1ec0d7515df17470e7d2fb8f10825d4', 'ADMIN'),
(602, NULL, 'usuario_60', 'b46ffe2fec8b8e11e561e4fa814e89b139de765b3d725dc3836e58e1d9dc851b', 'ADMIN'),
(603, NULL, 'usuario_61', 'aca06c42c4b17d30d8cd4191547e74cc5ecd167a5a591ddb51a2f59d5357bd02', 'ADMIN'),
(604, NULL, 'usuario_62', '908748ac07256c2714cb5948e8f756535d6160303d37ba065342a7864e5cdc6d', 'ADMIN'),
(605, NULL, 'usuario_63', '98008254bec84ef6dae96b120e8b7dd9798b2543870bb58414e0f074a61ba2d1', 'ADMIN'),
(606, NULL, 'usuario_64', '8d6db7954410516d85855daa2a70249ad0a49a98808e058d9807496a065c6ae0', 'ADMIN'),
(607, NULL, 'usuario_65', '75770605ceba48f88e7587eaeec7f4d616d00dd0ad536764d8b9b2ffb309d81f', 'ADMIN'),
(608, NULL, 'usuario_66', 'e85a4c75f7ca851642f78fb17614ac03e3fb69f734ea1ad49cbd0e90f632a4e1', 'ADMIN'),
(609, NULL, 'usuario_67', '4a3a9196e9992c474e7955504a9ebba13b8f29e76d89fd4662c0d8f8f483f219', 'ADMIN'),
(610, NULL, 'usuario_68', 'ebcbf699c684b3008f6157b4bb3ddc75d2e99f7f6568757cf6635f925fe3d41f', 'ADMIN'),
(611, NULL, 'usuario_69', 'ebc3bd75b98a85152226b934738997baf02bd33fe0aaa51a5f558e28aa49bd68', 'ADMIN'),
(612, NULL, 'usuario_70', 'd731742a333d210163f326ed7651febff2d47e3fbc6ec88901d6498ee6606867', 'ADMIN'),
(613, NULL, 'usuario_71', 'dbbe7d4e0ef98755ac64672b0635175a50f7593d212305dafb3bf33dab62ba08', 'ADMIN'),
(614, NULL, 'usuario_72', '3f0044c22de25386b3642062296c79b2ba512312529b263b66e169f60947972e', 'ADMIN'),
(615, NULL, 'usuario_73', '03e0c032d168f31f85956047d27f2f1937d060cc282ca55dfa1d846fa48ef33e', 'ADMIN'),
(616, NULL, 'usuario_74', '32a892d87b611f6565b3c7e4794a9c409d48023f1550e6419650885ff96e5b61', 'ADMIN'),
(617, NULL, 'usuario_75', '3929c1517a0989cdbcb9d9969fc0bcebfc8d1cb4ea812ba60c76ce3a9edf44c1', 'ADMIN'),
(618, NULL, 'usuario_76', 'f3e6375143c31e4cc1bb9f6065fcb4fae91e6fbfc69f481f93f91879b4f24f15', 'ADMIN'),
(619, NULL, 'usuario_77', '386d0d7da2ccddb5da8b182760c08a2bd07745a9c4a48c31b46ea03602dc209b', 'ADMIN'),
(620, NULL, 'usuario_78', '41d5bb3bd3d52143fc70da7a811d6a94f263331e4f431cd79b9d5d0e8d2a4d9c', 'ADMIN'),
(621, NULL, 'usuario_79', 'fa33721e40167899738d9b0be39cfbb5654516d1bed883460ed4eb1963e30445', 'ADMIN'),
(622, NULL, 'usuario_80', 'c6bbb09c799a3f32d6533e55c5b1bbee4cc9c0aced12857d28abeaa691915756', 'ADMIN'),
(623, NULL, 'usuario_81', 'a38fae2d613bee9cc12a3ed58e74a0db80f99c9fe759ebe5c536f69e08dcf647', 'ADMIN'),
(624, NULL, 'usuario_82', '828d4d02f0154b3a54da425e54f55b9cad8ee23e0112b2e1acbc51f45ece84a8', 'ADMIN'),
(625, NULL, 'usuario_83', '5da6194432fb43dc5f6daf8158f0742d203d674f6d6395ea9921f38b2e89ee1d', 'ADMIN'),
(626, NULL, 'usuario_84', 'fb37c82906477bc9ad7b7d0c9467f3b0c071ea3219b0442616012a5cd0485f15', 'ADMIN'),
(627, NULL, 'usuario_85', '869e27e6cedd57662328e097abf9b5ceb0a5caaf3569c99e650b1054a66c202c', 'ADMIN'),
(628, NULL, 'usuario_86', 'bb86986d5e1022810df32c17803e7092c727c0c1870f25ee3960790bbd8d429d', 'ADMIN'),
(629, NULL, 'usuario_87', 'fed9eedf238554cfb7719fb7cd6136e05e8d0cc3cfd6785c7085f8d4e8a2ee19', 'ADMIN'),
(630, NULL, 'usuario_88', '71f75d307ba5268c95e65ea4fff21bc83e919819d5c17080326d014d56d74a57', 'ADMIN'),
(631, NULL, 'usuario_89', 'd4f733d482bf096120712bb59df6f978663392c9bf84f04a4de148b1e0d3d7b7', 'ADMIN'),
(632, NULL, 'usuario_90', '597c7ddad0c4bcf7446543beb175a024c970ab80f306f9166e4212bf1888a54a', 'ADMIN'),
(633, NULL, 'usuario_91', '10d04a619d6933814647e152cba2a50ebc4120b85f51a9848701625feada8738', 'ADMIN'),
(634, NULL, 'usuario_92', 'd587533b60f29d5f6128355d5e8cbf7ec3d8ad719f2e6e11728a2371e249139b', 'ADMIN'),
(635, NULL, 'usuario_93', 'c931b0db04b5ed2db16373d7541ed42f9d7f58e41002b5b37e5857dd7f31d074', 'ADMIN'),
(636, NULL, 'usuario_94', 'acd4cff365dbcf37f3c9dbba13f0520234350e34c26ddc2ac2f437bad42a204e', 'ADMIN'),
(637, NULL, 'usuario_95', '8053ca04dae0a1cfda216f2967ba3f293449a57836cd2ba9d922321c23874b3b', 'ADMIN'),
(638, NULL, 'usuario_96', '961304a717ae5c849b66fe8ba2f541ffa0456de004d268673ccb2607f9972966', 'ADMIN'),
(639, NULL, 'usuario_97', 'b0f74fd6fb3b8b62b99098b8a39bb9d8bb85f6d0bb602b9d54cf6ae0d52bdb7c', 'ADMIN'),
(640, NULL, 'usuario_98', 'd1b82e8f6d1217916b154b1416757f321b6a8ea996cfd8c0f33cb6c6eb1c203f', 'ADMIN'),
(641, NULL, 'usuario_99', '89d1f063293c9744742b9dabd3a2a9c8bef67aa7f010cbff575f753ddf32f1f4', 'ADMIN'),
(642, NULL, 'usuario_100', '5400166be1072d6526e1c0ba36456a8e1e41aabf50fb05f1e997de5c67eb007c', 'ADMIN');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`ID_AGENDA`),
  ADD KEY `FK_RELATIONSHIP_10` (`ID_MEDICO`);

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
  ADD PRIMARY KEY (`ID_CITA`),
  ADD KEY `FK_RELATIONSHIP_1` (`ID_PACIENTE`),
  ADD KEY `FK_RELATIONSHIP_15` (`ID_MEDICO`);

--
-- Indices de la tabla `comprobante_cita`
--
ALTER TABLE `comprobante_cita`
  ADD PRIMARY KEY (`ID_COMPROBANTE`),
  ADD KEY `FK_RELATIONSHIP_8` (`ID_CITA`);

--
-- Indices de la tabla `comprobante_de_pago`
--
ALTER TABLE `comprobante_de_pago`
  ADD PRIMARY KEY (`ID_COMPRP`),
  ADD KEY `FK_RELATIONSHIP_19` (`ID_PAGO`);

--
-- Indices de la tabla `disponibilidad_medica`
--
ALTER TABLE `disponibilidad_medica`
  ADD PRIMARY KEY (`ID_DISPONIBILIDADM`),
  ADD KEY `FK_RELATIONSHIP_2` (`ID_MEDICO`);

--
-- Indices de la tabla `historia_clinica`
--
ALTER TABLE `historia_clinica`
  ADD PRIMARY KEY (`ID_HISTORIACLINICA`),
  ADD KEY `FK_RELATIONSHIP_9` (`ID_PACIENTE`);

--
-- Indices de la tabla `horario_medico`
--
ALTER TABLE `horario_medico`
  ADD PRIMARY KEY (`ID_HM`),
  ADD KEY `FK_RELATIONSHIP_11` (`ID_MEDICO`);

--
-- Indices de la tabla `medico`
--
ALTER TABLE `medico`
  ADD PRIMARY KEY (`ID_MEDICO`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`ID_PACIENTE`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`ID_PAGO`),
  ADD KEY `FK_RELATIONSHIP_3` (`ID_CITA`);

--
-- Indices de la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD PRIMARY KEY (`ID_SECCION`),
  ADD KEY `FK_RELATIONSHIP_12` (`ID_USUARIO`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID_USUARIO`),
  ADD KEY `FK_RELATIONSHIP_6` (`ID_MEDICO`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `agenda`
--
ALTER TABLE `agenda`
  MODIFY `ID_AGENDA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT de la tabla `cita`
--
ALTER TABLE `cita`
  MODIFY `ID_CITA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=449;

--
-- AUTO_INCREMENT de la tabla `comprobante_cita`
--
ALTER TABLE `comprobante_cita`
  MODIFY `ID_COMPROBANTE` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comprobante_de_pago`
--
ALTER TABLE `comprobante_de_pago`
  MODIFY `ID_COMPRP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `disponibilidad_medica`
--
ALTER TABLE `disponibilidad_medica`
  MODIFY `ID_DISPONIBILIDADM` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT de la tabla `historia_clinica`
--
ALTER TABLE `historia_clinica`
  MODIFY `ID_HISTORIACLINICA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=739;

--
-- AUTO_INCREMENT de la tabla `horario_medico`
--
ALTER TABLE `horario_medico`
  MODIFY `ID_HM` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT de la tabla `medico`
--
ALTER TABLE `medico`
  MODIFY `ID_MEDICO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `ID_PACIENTE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=609;

--
-- AUTO_INCREMENT de la tabla `pago`
--
ALTER TABLE `pago`
  MODIFY `ID_PAGO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT de la tabla `sesion`
--
ALTER TABLE `sesion`
  MODIFY `ID_SECCION` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=487;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID_USUARIO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=643;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `agenda`
--
ALTER TABLE `agenda`
  ADD CONSTRAINT `FK_RELATIONSHIP_10` FOREIGN KEY (`ID_MEDICO`) REFERENCES `medico` (`ID_MEDICO`);

--
-- Filtros para la tabla `cita`
--
ALTER TABLE `cita`
  ADD CONSTRAINT `FK_RELATIONSHIP_1` FOREIGN KEY (`ID_PACIENTE`) REFERENCES `paciente` (`ID_PACIENTE`),
  ADD CONSTRAINT `FK_RELATIONSHIP_15` FOREIGN KEY (`ID_MEDICO`) REFERENCES `medico` (`ID_MEDICO`);

--
-- Filtros para la tabla `comprobante_cita`
--
ALTER TABLE `comprobante_cita`
  ADD CONSTRAINT `FK_RELATIONSHIP_8` FOREIGN KEY (`ID_CITA`) REFERENCES `cita` (`ID_CITA`);

--
-- Filtros para la tabla `comprobante_de_pago`
--
ALTER TABLE `comprobante_de_pago`
  ADD CONSTRAINT `FK_RELATIONSHIP_19` FOREIGN KEY (`ID_PAGO`) REFERENCES `pago` (`ID_PAGO`);

--
-- Filtros para la tabla `disponibilidad_medica`
--
ALTER TABLE `disponibilidad_medica`
  ADD CONSTRAINT `FK_RELATIONSHIP_2` FOREIGN KEY (`ID_MEDICO`) REFERENCES `medico` (`ID_MEDICO`);

--
-- Filtros para la tabla `historia_clinica`
--
ALTER TABLE `historia_clinica`
  ADD CONSTRAINT `FK_RELATIONSHIP_9` FOREIGN KEY (`ID_PACIENTE`) REFERENCES `paciente` (`ID_PACIENTE`);

--
-- Filtros para la tabla `horario_medico`
--
ALTER TABLE `horario_medico`
  ADD CONSTRAINT `FK_RELATIONSHIP_11` FOREIGN KEY (`ID_MEDICO`) REFERENCES `medico` (`ID_MEDICO`);

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `FK_RELATIONSHIP_3` FOREIGN KEY (`ID_CITA`) REFERENCES `cita` (`ID_CITA`);

--
-- Filtros para la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD CONSTRAINT `FK_RELATIONSHIP_12` FOREIGN KEY (`ID_USUARIO`) REFERENCES `usuario` (`ID_USUARIO`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `FK_RELATIONSHIP_6` FOREIGN KEY (`ID_MEDICO`) REFERENCES `medico` (`ID_MEDICO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
